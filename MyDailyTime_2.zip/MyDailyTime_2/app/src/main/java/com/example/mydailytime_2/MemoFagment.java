package com.example.mydailytime_2;


import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class MemoFagment extends Fragment {

    public MemoFagment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_memo_fagment, container, false);

        TextInputLayout textInputLayout1 =(TextInputLayout)view.findViewById(R.id.tiTleTextLayout1);
        //TextInputLayout textInputLayout2 =(TextInputLayout)view.findViewById(R.id.tiTleTextLayout2);
        TextInputEditText textInputEditText1 =(TextInputEditText)view.findViewById(R.id.tiTleMemoPage3);
        //TextInputEditText textInputEditText2 =(TextInputEditText)view.findViewById(R.id.tiTleMemo2Page3);


        return view;


    }

}
